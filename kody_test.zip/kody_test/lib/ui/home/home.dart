import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:kody_test/freamwork/repository/home/home_model.dart';
import 'package:responsive_builder/responsive_builder.dart';

import 'moible/home_mobile.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> {
 static Welcome? welcome;
  @override
  void initState() {
    super.initState();
    loadHomeJson();
  }

  Future<void> loadHomeJson() async {
    final String response = await rootBundle.loadString(
      'assets/json/json_menubox.json',
    );
    final data = welcomeFromJson(response);
    setState(() {
      welcome = data;
      print("data== $welcome");
    });
  }

  @override
  Widget build(BuildContext context) {
    return ScreenTypeLayout.builder(
      mobile: (BuildContext context){
        return HomeMobile();
      },
    );
  }
}
