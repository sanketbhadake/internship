import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kody_test/freamwork/controller/based_controller.dart';
import 'package:kody_test/freamwork/repository/home/home_model.dart';
import 'package:kody_test/ui/utils/Widgets/common_container.dart';
import 'package:kody_test/ui/utils/Widgets/common_net_image.dart';
import 'package:kody_test/ui/utils/Widgets/common_sizedbox.dart';
import 'package:kody_test/ui/utils/Widgets/common_text.dart';

import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class HomeMobile extends StatefulWidget {
  const HomeMobile({super.key});

  @override
  State<HomeMobile> createState() => _HomeMobileState();
}

class _HomeMobileState extends State<HomeMobile> {
  int _currentIndex = 0;

  Welcome? welcome;

  @override
  void initState() {
    super.initState();
    loadHomeJson();
    print("data loaded===");
  }

  Future<void> loadHomeJson() async {
    final String response = await rootBundle.loadString(
      'assets/json/json_menubox.json',
    );
    final data = welcomeFromJson(response);
    setState(() {
      welcome = data;
      print("data===== $welcome");
    });
  }

  @override
  Widget build(BuildContext context) {
    final sizedWidth = MediaQuery.of(context).size.width;
    final sizedHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  height: 100,
                  width: MediaQuery.of(context).size.width,
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(14),
                      bottomRight: Radius.circular(14),
                    ),
                    color: Color(0xff070707),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Row(
                      children: [
                        SvgPicture.asset("assets/svgs/svg_category.svg"),
                        
                        Spacer(),

                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Your location",
                              style: TextStyle(color: Colors.white),
                            ),
                            GestureDetector(
                              onTap: () {},
                              child: Row(
                                children: [
                                  Text(
                                    "Punjab, India",
                                    style: TextStyle(color: Colors.white),
                                  ),
                                  Icon(Icons.keyboard_arrow_down_rounded,color: Colors.white,)
                                ],
                              ),
                            ),
                          ],
                        ),
                        Spacer(),

                        Icon(Icons.notifications_outlined, color: Colors.white),
                        Space.w10,
                        Icon(
                          Icons.favorite_border_rounded,
                          color: Colors.white,
                        ),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  top: 80,
                  left: 40,
                  child: Container(
                    height: 44,
                    width: sizedWidth * 0.8,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),

                      color: Colors.white,
                    ),
                    child: TextField(
                      decoration: InputDecoration(
                        prefixIcon: Icon(Icons.search_sharp),
                        border: InputBorder.none,
                        hint: Text(
                          "Restaurants, Foods...",
                          style: TextStyle(color: Colors.grey),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),

            Space.h20,
            Space.h20,

            ///CarouselSlider
            CarouselSlider(
              items: welcome?.banner?.map((data) {
                return Container(
                  height: sizedHeight,
                  width: sizedWidth,

                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: CommonNetworkImage(imageUrl: data),
                );
              }).toList(),

              options: CarouselOptions(
                height: 120,
                viewportFraction: 0.7,
                autoPlay: true,
                autoPlayCurve: Curves.easeInOut,
                enlargeCenterPage: true,
                animateToClosest: true,
                onPageChanged: (index, reason) {
                  setState(() {
                    _currentIndex = index;
                  });
                },
              ),
            ),
            Space.h20,
            Center(
              child: SmoothPageIndicator(
                controller: PageController(initialPage: _currentIndex),
                count: welcome?.banner?.length ?? 0,
                effect: ExpandingDotsEffect(
                  dotHeight: 7,
                  dotWidth: 7,
                  expansionFactor: 7,
                  activeDotColor: Colors.black,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CommonText(text: "Categories", weight: FontWeight.bold),
                  Space.h20,

                  GridView.builder(
                    shrinkWrap: true,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisSpacing: 20,
                      childAspectRatio: 0.7,
                      crossAxisCount: 3,
                      mainAxisExtent: 120,
                      mainAxisSpacing: 20,
                    ),
                    itemCount: welcome?.categories?.length,
                    itemBuilder: (context, index) {
                      return Container(
                        height: 100,
                        width: 95,
                        child: Column(
                          children: [
                            CommonNetworkImage(
                              imageUrl: welcome?.categories?[index].image ?? '',
                              width: 95,
                              height: 95,
                            ),
                            // Spacer(),
                            CommonText(
                              text: welcome?.categories?[index].name ?? '',
                            ),
                          ],
                        ),
                      );
                    },
                  ),

                  CommonText(
                    text: "Recently Ordered On MenuBox",
                    weight: FontWeight.bold,
                  ),
                  Space.h20,
                  SizedBox(
                    height: 140,
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: welcome?.recentOrders?.length,
                      scrollDirection: Axis.horizontal,

                      itemBuilder: (context, index) {
                        return Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(right: 15.0),
                              child: CommonContainer(
                                height: 80,
                                width: 80,
                                borderRadius: 16,
                                color: Colors.white,
                                shadow: true,
                                child: Image.network(
                                  welcome?.recentOrders?[index].image ?? '',
                                  height: 10,
                                  width: 10,
                                  errorBuilder: (context, error, stackTrace) {
                                    return Image.network(
                                      "https://m.media-amazon.com/images/I/71DCZ-I6agL._AC_UF894,1000_QL80_.jpg",
                                      height: 10,
                                      width: 10,
                                    );
                                  },
                                ),
                              ),
                            ),
                            Space.h10,
                            CommonText(
                              text: welcome?.recentOrders?[index].name ?? '',
                              fontSize: 12,
                            ),
                          ],
                        );
                      },
                    ),
                  ),

                  Row(
                    children: [
                      CommonText(
                        text: "Exciting Offers",
                        weight: FontWeight.bold,
                      ),
                      Spacer(),
                      CommonText(text: "View All", weight: FontWeight.bold),
                    ],
                  ),

                  ListView.builder(
                    shrinkWrap: true,
                    itemCount: welcome?.existingOffers?.length,
                    itemBuilder: (context, index) => CommonContainer(
                      child: Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: CommonContainer(
                              child: Image.network(
                                welcome?.existingOffers?[index].image ?? '',
                                height: 40,
                                width: 40,
                                errorBuilder: (context, error, stackTrace) {
                                  return Image.network(
                                    "https://m.media-amazon.com/images/I/71DCZ-I6agL._AC_UF894,1000_QL80_.jpg",
                                    height: 40,
                                    width: 40,
                                  );
                                },
                              ),
                            ),
                          ),
                          Space.w10,
                          Space.w10,
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CommonText(
                                text:
                                    welcome?.existingOffers?[index].name ?? '',
                                weight: FontWeight.bold,
                              ),
                              CommonText(
                                text:
                                    welcome?.existingOffers?[index].subtitle ??
                                    '',
                                color: Colors.grey,
                                // ),CommonText(
                                //   text:welcome?.existingOffers?[index].offerTitle?? '',
                                //   color: Colors.green,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  Space.h20,
                  Row(
                    children: [
                      CommonText(
                        text: "In the Spotlight",
                        weight: FontWeight.bold,
                      ),
                      Spacer(),
                      CommonText(text: "View ALL", weight: FontWeight.bold),
                    ],
                  ),
                  Space.h20,
                  SizedBox(
                    height: 140,
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: welcome?.spotlight?.length,
                      scrollDirection: Axis.horizontal,

                      itemBuilder: (context, index) {
                        return Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(right: 15.0),
                              child: CommonContainer(
                                height: 80,
                                width: 80,
                                borderRadius: 16,
                                color: Colors.white,
                                shadow: true,
                                child: Image.network(
                                  welcome?.spotlight?[index].image ?? '',
                                  height: 10,
                                  width: 10,
                                  errorBuilder: (context, error, stackTrace) {
                                    return Image.network(
                                      "https://m.media-amazon.com/images/I/71DCZ-I6agL._AC_UF894,1000_QL80_.jpg",
                                      height: 10,
                                      width: 10,
                                    );
                                  },
                                ),
                              ),
                            ),
                            Space.h10,
                            CommonText(
                              text: welcome?.spotlight?[index].name ?? '',
                              fontSize: 12,
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                  CommonText(text: "All Store", weight: FontWeight.bold),
                  Space.h20,
                  ListView.builder(
                    shrinkWrap: true,
                    itemCount: welcome?.stores?.length,
                    itemBuilder: (context, index) => Padding(
                      padding: const EdgeInsets.only(bottom: 15.0),
                      child: Stack(
                        children: [
                          CommonContainer(
                            shadow: true,
                            color: Colors.white,
                            child: Column(
                              children: [
                                CommonContainer(
                                  height: 130,
                                  borderRadius: 14,
                                  width: double.infinity,

                                  child: Image.network(
                                    welcome?.stores?[index].banner ?? '',
                                    width: double.infinity,
                                    fit: BoxFit.cover,
                                    errorBuilder: (context, error, stackTrace) {
                                      return Image.network(
                                        "https://m.media-amazon.com/images/I/71DCZ-I6agL._AC_UF894,1000_QL80_.jpg",
                                        width: double.infinity,
                                        fit: BoxFit.cover,
                                      );
                                    },
                                  ),
                                ),
                                CommonContainer(
                                  color: Colors.white,
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Column(
                                      children: [
                                        Row(
                                          children: [
                                            CommonText(
                                              text:
                                                  welcome
                                                      ?.stores?[index]
                                                      .name ??
                                                  '',
                                            ),
                                            Spacer(),
                                            CommonText(
                                              text:
                                                  "Free delivery up to ${welcome?.stores?[index].freeDeliveryKm ?? ''} km",
                                              color: Colors.green,
                                            ),
                                          ],
                                        ),
                                        Row(
                                          children: [
                                            Icon(Icons.star),
                                            CommonText(
                                              text:
                                                  welcome
                                                      ?.stores?[index]
                                                      .rating ??
                                                  '',
                                            ),

                                            CommonText(
                                              text:
                                                  "(${welcome?.stores?[index].review ?? ''})",
                                              color: Colors.grey,
                                            ),
                                            Spacer(),
                                            Icon(Icons.timer),
                                            CommonText(
                                              text:
                                                  "${welcome?.stores?[index].deliveryTime ?? ''}min",
                                            ),
                                          ],
                                        ),
                                        Row(
                                          children: [
                                            CommonText(
                                              text: "Mini order",
                                              color: Colors.grey,
                                            ),
                                            CommonText(
                                              text:
                                                  "${welcome?.stores?[index].minOrder ?? ''} INR",
                                            ),

                                            Spacer(),
                                            Icon(Icons.location_on),
                                            CommonText(
                                              text:
                                                  "${welcome?.stores?[index].distance ?? ''} km",
                                              color: Colors.grey,
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  height: 30,

                                  decoration: BoxDecoration(
                                    color: Colors.green,
                                    borderRadius: BorderRadius.only(
                                      bottomRight: Radius.circular(12),
                                      bottomLeft: Radius.circular(12),
                                    ),
                                  ),

                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 50,
                                    ),
                                    child: Row(
                                      children: [
                                        CommonText(
                                          text:
                                              welcome!
                                                  .stores![index]
                                                  .offer
                                                  ?.title ??
                                              '',
                                        ),
                                        Spacer(),
                                        CommonText(
                                          text:
                                              welcome!
                                                  .stores![index]
                                                  .offer
                                                  ?.code ??
                                              '',
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Positioned(
                            top: 15,
                            left: 10,
                            child: CircleAvatar(
                              radius: 35,
                              backgroundColor: Colors.grey,
                              backgroundImage: NetworkImage(
                                welcome?.stores?[index].banner ?? '',
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar:BottomNavigationBar(items: BasedController.navigation.map((data){
        return BottomNavigationBarItem(icon: data.icon,label: data.label);
      }).toList(),
      selectedItemColor: Colors.black,
      unselectedItemColor: Colors.grey,
      ) ,



    );
  }
}
