import 'package:flutter/material.dart';
import 'package:kody_test/freamwork/repository/based_model.dart';

import '../../ui/home/home.dart';

class BasedController {
  static int currentIndex = 0;
  static List<BasedModel> navigation = [
    BasedModel(
      label: "home",
      icon: Icon(Icons.home),
      id: 0,
      screen: HomeScreen(),
    ),
    BasedModel(
      label: "order",
      icon: Icon(Icons.calendar_today_outlined),
      id: 1,
      screen: HomeScreen(),
    ),
    BasedModel(
      label: "cart",
      icon: Icon(Icons.shopping_cart),
      id: 2,
      screen: HomeScreen(),
    ),
    BasedModel(
      label: "profile",
      icon: Icon(Icons.person),
      id: 3,
      screen: HomeScreen(),
    ),
  ];
}
