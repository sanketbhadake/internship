import 'package:actiday/framework/repository/favourite/favourite_model.dart';

class FavouriteController {
  static List<FavouriteModel> favouriteList=[];
}