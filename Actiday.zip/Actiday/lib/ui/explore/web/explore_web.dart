import 'package:flutter/material.dart';

class ExploreWeb extends StatefulWidget {
  const ExploreWeb({super.key});

  @override
  State<ExploreWeb> createState() => _ExploreWebState();
}

class _ExploreWebState extends State<ExploreWeb> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
