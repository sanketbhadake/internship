enum BottomNaviItems{
  Home,
  Booking,
  Explore,
  Favourite
}
enum Status {
  BOOK,
  CONTINUE
}