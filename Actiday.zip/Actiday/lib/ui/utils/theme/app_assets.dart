class AppAssets {
  static const String splashLogo = "assets/svgs/splash_logo.svg";
  static const String category = "assets/svgs/category-2.svg";
  static const String womenImage = "assets/images/women_image.png";

  static const String banner = "assets/images/banner.png";





}
