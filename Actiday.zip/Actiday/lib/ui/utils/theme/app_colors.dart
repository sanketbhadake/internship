import 'package:flutter/material.dart';

class AppColors {
  static const appBarColor =Color(0xffF0F5F9);
  static const spaColor =Color(0xffF048C6);
  static const fitColor =Color(0xffF048C6);
}