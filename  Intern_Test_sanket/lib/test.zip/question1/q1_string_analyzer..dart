import 'package:intern_test_sanket/question1/common.dart';

class MenuLogic {
  static void countVowels(String str) {
    int vowel = 0, consonants = 0;

    for (int i = 0; i < str.length; i++) {
      if ( "aeiouAEIOU".contains(str[i]) ) {

        vowel++;
      } else {
        consonants++;
      }
    }
    Common.printer(" Count of Vowels : $vowel");
    Common.printer(" Count of Consonants : $consonants");

  }
  static String reverseString(String str){
    String reverse=str.split('').reversed.join();
    return reverse;
  }

  static String convertUppercase(String str){
   String upperCase= str.replaceAll( RegExp(r'^[a-z]'), '');

 return upperCase;
  }

}
