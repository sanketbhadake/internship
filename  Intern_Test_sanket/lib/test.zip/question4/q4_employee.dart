class Employee {
  String? name;
  int? id;

  int calculateSal() {
    return 0;
  }
}

class Fulltime extends Employee {
  double? monthlySal;

  @override
  int calculateSal() {
    return 0;
  }
}

class ContractEmployee extends Employee {
  int? hourlyRate;
  int? hoursWorked;

  @override
  int calculateSal() {
    return 0;
  }
}
