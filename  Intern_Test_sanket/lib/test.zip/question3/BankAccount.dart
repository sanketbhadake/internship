import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intern_test_sanket/question1/common.dart';

class BankAccount {
  String _accountNumber;

  String? _accountHolder;
  double _balance = 0;

  BankAccount.accountHolder(this._balance,
      this._accountHolder,
      this._accountNumber,);

  BankAccount.accountNumber(this._balance,
      this._accountHolder,
      this._accountNumber,);

  String get accountNumber => _accountNumber;

  set accountNumber(String value) {
    _accountNumber = value;
  }

  double get balance => _balance;

  void deposit(double amount) {
    if (amount > 0) {
      _balance = amount;
    }
  }
}

void main() {
  double amount;

  Common.printer("Enter the amount");
  amount = double.tryParse(stdin.readLineSync() ?? "0") ?? 0;

  // BankAccount.deposite(amount);
  // BankAccount.accountHolder(amount, "sanket", "123566");
}
