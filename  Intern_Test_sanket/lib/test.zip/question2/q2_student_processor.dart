class Student {
  static List<Map<String, dynamic>> studentScores = [
    {
      'name': 'Alice',
      'scores': [85, 90, 88],
    },
    {
      'name': 'Bob',
      'scores': [70, 65, 75],
    },
    {
      'name': 'Charlie',
      'scores': [95, 92, 98],
    },
    {
      'name': 'Diana',
      'scores': [50, 45, 55],
    },
  ];

  static double averageScore() {
    List score=[];
    for(int i =0;i<studentScores.length;i++){
      score.add(studentScores[i]['scores'][i]);
    }
  print(score);

    return 0;
  }
}
