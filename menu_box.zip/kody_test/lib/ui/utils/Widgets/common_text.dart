import 'package:flutter/material.dart';

class CommonText extends StatelessWidget {
  final String text;
  final double? fontSize;
  final Color? color;
  final FontWeight? weight;
  final bool center;
  final bool overFlow;

  const CommonText({
    super.key,
    required this.text,
    this.fontSize,
    this.center = false,
    this.overFlow = false,
    this.color,
    this.weight,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      textAlign: center ? TextAlign.center : TextAlign.start,
      overflow: overFlow ? TextOverflow.ellipsis : null,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: weight ?? FontWeight.w500,
        color: color ?? Colors.black,
      ),
    );
  }
}
