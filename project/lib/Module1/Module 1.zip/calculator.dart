import 'dart:io';
class Calculator{

  static int add(int num1,int num2){
    return num1+num2;
  }
  static int sub(int num1,int num2){
    return num1-num2;
  }
  static int mul(int num1,int num2){
    return num1*num2;
  }
  static double div(int num1,int num2){
    return num1/num2;
  }

}
